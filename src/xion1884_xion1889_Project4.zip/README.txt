Group Member Names and x500:
Samantha Xiong (xion1884)
Alex Xiong (xion1889)

Contributions of each person:
makeMaze: Samantha Xiong
printMaze: Alex Xiong
solveMaze: Samantha and Alex Xiong

Assumptions:
- number of columns must be bigger than 1
- number of rows much be bigger than 0

Additional Features:
- n/a

Bugs/Defects:
- rarely, when maze is printed, [0][0] does not have "*", meaning it has not been visited

Credit:
- https://www.usna.edu/Users/cs/aviv/classes/ic312/f16/project/01/project.html
- https://en.wikipedia.org/wiki/Maze_generation_algorithm#Depth-first_search